#include <omnetpy.h>

Define_Python_Module("fifo", "PyFifo");
Define_Python_Module("sink", "PySink");
Define_Python_Module("source", "PySource");

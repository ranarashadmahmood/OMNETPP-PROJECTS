PyFifo
======

Python implementation of Fifo sample.

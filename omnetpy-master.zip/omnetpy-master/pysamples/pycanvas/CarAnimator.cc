#include <omnetpy.h>

Define_Python_Module("car_animator", "PyCarAnimator");

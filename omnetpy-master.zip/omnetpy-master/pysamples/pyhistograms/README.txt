Pyhistogram demo
================

Python reimplementation of histogram sample.

#include <omnetpy.h>

Define_Python_Module("histograms", "PyHistograms");

#include <omnetpy.h>


Define_Python_Module("pyqueue", "PyQueue");

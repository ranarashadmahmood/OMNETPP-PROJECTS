(py)CQN (Closed Queueing Network)
=============================

python reimplementation of the cqn sample.

from txc10 import PyTxc10

PyTxc11 = PyTxc10

TicToc
======

This example simulation is a rewrite of the classical TicToc Tutorial using python defined classes.

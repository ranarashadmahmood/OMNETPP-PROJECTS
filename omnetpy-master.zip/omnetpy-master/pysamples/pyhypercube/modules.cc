#include <omnetpy.h>

Define_Python_Module("hcgenerator", "HCGenerator");
Define_Python_Module("hcrouter", "HCRouter");
Define_Python_Module("hcsink", "HCSink");

pyHCUBE
=======

Python reimplementation of sample hypercube.

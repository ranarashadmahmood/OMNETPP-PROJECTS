#include <omnetpy.h>

Define_Python_Module("pymodules", "App");
Define_Python_Module("pymodules", "L2Queue");
Define_Python_Module("pymodules", "NetBuilder");
Define_Python_Module("pymodules", "Node");
Define_Python_Module("pymodules", "Routing");

Parallel version of the Routing example
=======================================

This example demonstrates the parallel distributed simulation capabilities
of OMNeT++. The model itself is the "stock" Routing simulation -- it hasn't 
been modified or specially instrumented for parallel execution.

For more information on parallel simulation see the README in the cqn/parsim 
directory and the OMNeT++ Manual.

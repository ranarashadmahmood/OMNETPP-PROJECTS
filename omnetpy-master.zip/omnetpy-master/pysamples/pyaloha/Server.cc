#include <omnetpy.h>

Define_Python_Module("server", "PyServer");

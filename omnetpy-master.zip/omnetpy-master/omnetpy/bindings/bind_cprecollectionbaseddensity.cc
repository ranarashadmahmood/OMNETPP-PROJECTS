#include <pybind11/pybind11.h>

#include <omnetpp.h>


void bind_cPrecollectionBasedDensityEst(pybind11::module &m)
{
}

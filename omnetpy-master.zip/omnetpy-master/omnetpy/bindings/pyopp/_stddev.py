"""Bindings for cStdDev."""
from . import _pybind

cStdDev = _pybind._cStdDev

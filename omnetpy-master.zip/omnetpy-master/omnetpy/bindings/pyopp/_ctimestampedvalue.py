"""Bindings for cTimestampedValue."""
from . import _pybind

cTimestampedValue = _pybind._cTimestampedValue

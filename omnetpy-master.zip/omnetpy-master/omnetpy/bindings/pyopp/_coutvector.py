"""Bindings for cOutVector."""
from . import _pybind

cOutVector = _pybind._cOutVector

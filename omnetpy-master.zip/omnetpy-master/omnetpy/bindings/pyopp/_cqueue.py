"""Bindings for cQueue."""
from . import _pybind

cQueue = _pybind._cQueue

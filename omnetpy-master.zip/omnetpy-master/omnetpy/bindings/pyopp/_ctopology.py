"""Bindings related to cTopology."""
from . import _pybind

cTopology = _pybind._cTopology

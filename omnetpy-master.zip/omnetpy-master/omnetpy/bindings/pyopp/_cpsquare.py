"""Bindings related to cPSquare."""
from . import _pybind

cPSquare = _pybind._cPSquare
